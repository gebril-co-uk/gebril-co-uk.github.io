
import matplotlib.pyplot as plt

# Sample data
x = [1, 2, 3, 4, 5]
y = [10, 12, 15, 18, 20]

# Create plot
plt.plot(x, y, marker='o')
plt.title('Sample Plot')
plt.xlabel('X-axis')
plt.ylabel('Y-axis')
plt.grid(True)

# Save plot
plt.savefig('sample_plot.png')
plt.show()
