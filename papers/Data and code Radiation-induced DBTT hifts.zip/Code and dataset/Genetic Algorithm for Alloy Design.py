#A Data-Driven Machine Learning Model for Radiation-Induced DBTT Shifts in RAFM Steels
#By Pengxin Wang and G. M. A. M. El-Fallah
#Contact Dr Gebril El-Fallah:  gmae2@leicester.ac.uk
import pandas as pd
import numpy as np
import random
import warnings
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import StackingRegressor, GradientBoostingRegressor, RandomForestRegressor
from xgboost import XGBRegressor
from sklearn.linear_model import Ridge
from sklearn.neural_network import MLPRegressor
from deap import base, creator, tools, algorithms

warnings.filterwarnings("ignore", category=UserWarning)

# ==== 1. Load Data ====
df = pd.read_excel("Dataset.xlsx")
X = df.drop(columns=["DBTT (℃)"])
y = df["DBTT (℃)"]
feature_names = X.columns.tolist()
feature_bounds = {feature: (X[feature].min(), X[feature].max()) for feature in feature_names}

# ==== 2. Standardize ====
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# ==== 3. Best Stacking Model ====
stacking_model = StackingRegressor(
    estimators=[
        ('xgb', XGBRegressor(
            n_estimators=1801,
            learning_rate=0.012152412584802449,
            max_depth=6,
            subsample=0.524776882713048,
            colsample_bytree=0.8884256147730027,
            verbosity=0)),
        ('gbdt', GradientBoostingRegressor(
            n_estimators=1798,
            learning_rate=0.03443571805280876,
            max_depth=3,
            subsample=0.9973541710009287)),
        ('rf', RandomForestRegressor(
            n_estimators=208,
            max_depth=26,
            min_samples_split=2,
            min_samples_leaf=1,
            random_state=42)),
        ('mlp', MLPRegressor(
            hidden_layer_sizes=(100, 100),
            activation='relu',
            alpha=0.00014521650659547858,
            learning_rate_init=0.02663798210178525,
            max_iter=767,
            random_state=42))
    ],
    final_estimator=Ridge()
)
stacking_model.fit(X_train, y_train)

# ==== 4. Genetic Algorithm ====
creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
creator.create("Individual", list, fitness=creator.FitnessMin)
toolbox = base.Toolbox()

fixed_zero_features = ["S", "P", "Ni", "N", "Nb", "Cu", "Mo", "B", "Ce", "Ge", "Zr", "Ti", "Co", "Al"]
must_be_positive = [f for f in feature_names if f not in fixed_zero_features + ["C", "Cr", "Dose (dpa)", "Tirr", "W", "V"]]
C_range = (0.08, 0.15)
Cr_range = (0, 10)
W_range = (0, 5)
V_range = (0, 2)
Dose_fixed = 10.0
DBTT_range = (-50, 50)
n_solutions = 10

# ==== Individual Generator ====
def generate_individual():
    ind = []
    for feature in feature_names:
        if feature == "Tirr":
            ind.append(random.uniform(200, 350))
        elif feature == "Dose (dpa)":
            ind.append(Dose_fixed)
        elif feature == "Cr":
            ind.append(random.uniform(*Cr_range))
        elif feature == "C":
            ind.append(random.uniform(*C_range))
        elif feature == "W":
            ind.append(random.uniform(*W_range))
        elif feature == "V":
            ind.append(random.uniform(*V_range))
        elif feature in fixed_zero_features:
            ind.append(0.0)
        elif feature in must_be_positive:
            ind.append(random.uniform(0.001, feature_bounds[feature][1]))
        else:
            ind.append(random.uniform(*feature_bounds[feature]))
    return creator.Individual(ind)

# ==== Fitness Evaluation ====
def evaluate(individual):
    values = {f: v for f, v in zip(feature_names, individual)}

    # Constraints
    if not (0.08 <= values["C"] <= 0.15): return (1e6,)
    if not (0 <= values["Cr"] <= 10): return (1e6,)
    if not (0 <= values["W"] <= 5): return (1e6,)
    if not (0 <= values["V"] <= 2): return (1e6,)
    if not (250 <= values["Tirr"] <= 350): return (1e6,)
    if not (values["Dose (dpa)"] == Dose_fixed): return (1e6,)
    for f in fixed_zero_features:
        if abs(values[f]) > 1e-6: return (1e6,)
    for f in must_be_positive:
        if values[f] <= 0: return (1e6,)

    pred = stacking_model.predict(scaler.transform([individual]))[0]
    if not (DBTT_range[0] <= pred <= DBTT_range[1]):
        return (abs(pred) + 1000,)  # heavy penalty
    return (abs(pred),)  # the lower the DBTT, the better

# ==== Register Genetic Operators ====
toolbox.register("individual", generate_individual)
toolbox.register("population", tools.initRepeat, list, toolbox.individual)
toolbox.register("evaluate", evaluate)
toolbox.register("mate", tools.cxBlend, alpha=0.5)
toolbox.register("mutate", tools.mutGaussian, mu=0, sigma=0.1, indpb=0.2)
toolbox.register("select", tools.selTournament, tournsize=3)

# ==== Run Genetic Algorithm ====
pop = toolbox.population(n=100)
hof = tools.HallOfFame(n_solutions)
stats = tools.Statistics(lambda ind: ind.fitness.values)
stats.register("min", np.min)
stats.register("avg", np.mean)

algorithms.eaSimple(pop, toolbox, cxpb=2.0, mutpb=0.8, ngen=120,
                    stats=stats, halloffame=hof, verbose=True)

# ==== Save Optimised Results ====
result_rows = []
for ind in hof:
    pred = stacking_model.predict(scaler.transform([ind]))[0]
    row = {f: v for f, v in zip(feature_names, ind)}
    row["Predicted DBTT (℃)"] = pred
    result_rows.append(row)

df_result = pd.DataFrame(result_rows)
df_result.to_excel("results.xlsx", index=False)


